# readme
ctrl +B : build
: main .\grids\grid_Dstar_journal.map m

cls # clear

clean # delete compair

dir #pwd